# SOUQI — سوقي

مشروع تجارة إلكترونية عربي-first مبني بـ Next.js + TypeScript + Prisma + PostgreSQL.

## الحالة الحالية

هذه النسخة تحتوي على أساس مشروع حقيقي قابل للتطوير: بنية قاعدة البيانات، واجهة RTL، صفحات المتجر، صفحات الحساب والإدارة، seed data، وتهيئة Auth.js. بعض تدفقات التجارة المتقدمة (مثل تنفيذ إجراءات السلة/checkout الفعلية، رفع R2، وإدارة CRUD الكاملة في لوحة الإدارة) تحتاج استكمالها قبل اعتبار المشروع إنتاجيًا.

## المتطلبات

- Node.js حديث
- PostgreSQL
- npm

## التثبيت

```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

ثم افتح http://localhost:3000

## البيئة

اضبط `DATABASE_URL` و`AUTH_SECRET`. لإنشاء مدير تطوير، اضبط `ADMIN_EMAIL` و`ADMIN_PASSWORD` ثم شغل seed.

## Cloudflare

هذه البنية تتجنب APIs الخاصة بـ Vercel. ومع ذلك، Next.js + Prisma التقليدي يحتاج بيئة Node/Postgres في هذا الشكل، بينما Cloudflare Workers يتطلب مسار نشر متوافق مع runtime الخاص بـ Cloudflare وطبقة قاعدة بيانات/ORM مناسبة. قبل الإنتاج على Workers، يجب اعتماد adapter/دعم Prisma الخاص بـ Cloudflare المتاح وقت النشر واختباره في مشروعك.

## R2

حقول `CLOUDFLARE_ACCOUNT_ID` و`R2_BUCKET_NAME` موجودة لتجهيز طبقة التخزين المستقبلية. لا يتم رفع الصور إلى R2 تلقائيًا في هذه النسخة.

## الأمان

لا تضع أسرارًا حقيقية في Git. راجع سياسات الخصوصية والشروط قانونيًا قبل النشر.

## أوامر مفيدة

- `npm run dev`
- `npm run build`
- `npm run lint`
- `npm run typecheck`
- `npm run db:migrate`
- `npm run db:seed`
