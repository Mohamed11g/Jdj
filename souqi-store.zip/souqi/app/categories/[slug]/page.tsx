import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { ProductCard } from "@/components/product-card";
export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) { const {slug}=await params; const c=await db.category.findUnique({where:{slug},include:{products:{where:{isPublished:true},include:{images:{orderBy:{sortOrder:"asc"},take:1},category:true}}}}); if(!c)notFound(); return <main className="container py-12"><h1 className="text-4xl font-bold">{c.name}</h1><div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">{c.products.map(p=><ProductCard key={p.id} product={p}/>)}</div></main> }
