import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "سوقي | كل ما تحتاجه في مكان واحد", template: "%s | سوقي" },
  description: "سوقي — تجربة تسوق عربية حديثة وسريعة في المغرب.",
  openGraph: { title: "سوقي", description: "كل ما تحتاجه في مكان واحد", type: "website" }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body><Navbar />{children}<Footer /></body></html>;
}
