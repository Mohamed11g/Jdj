import { notFound } from "next/navigation";
import Image from "next/image";
import { db } from "@/lib/db";
import { formatMAD } from "@/lib/utils";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
 const { slug } = await params;
 const p = await db.product.findUnique({ where: { slug }, include: { images: { orderBy: { sortOrder: "asc" } }, category: true, variants: true, reviews: { where: { isPublished: true }, take: 10 } }});
 if (!p || !p.isPublished) notFound();
 return <main className="container py-10"><div className="grid gap-10 md:grid-cols-2">
  <div className="grid gap-3 sm:grid-cols-2">{p.images.map(i=><div key={i.id} className="relative aspect-square overflow-hidden rounded-3xl bg-white"><Image src={i.url} alt={i.alt} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover"/></div>)}</div>
  <div><p className="text-sm font-semibold text-[var(--primary)]">{p.category.name}</p><h1 className="mt-2 text-4xl font-bold">{p.name}</h1><div className="mt-5 flex items-center gap-3"><strong className="text-3xl">{formatMAD(p.basePrice)}</strong>{p.compareAtPrice && <del className="text-slate-400">{formatMAD(p.compareAtPrice)}</del>}</div><p className="mt-6 leading-8 text-[var(--muted)]">{p.description}</p>{p.variants.length > 0 && <div className="mt-7"><label className="font-semibold">اختر النوع</label><select className="mt-2 w-full rounded-xl border border-[var(--border)] bg-white p-3">{p.variants.map(v=><option key={v.id}>{v.name}</option>)}</select></div>}<div className="mt-7 grid gap-3 sm:grid-cols-2"><button className="rounded-xl bg-[var(--foreground)] px-5 py-4 font-semibold text-white">أضف للسلة</button><button className="rounded-xl border border-[var(--border)] px-5 py-4 font-semibold">شراء الآن</button></div><div className="mt-8 rounded-2xl bg-white p-5"><p className="font-semibold">الدفع عند الاستلام متاح</p><p className="mt-1 text-sm text-[var(--muted)]">سيتم تأكيد تفاصيل التوصيل قبل تجهيز الطلب.</p></div></div>
 </div></main>
}
