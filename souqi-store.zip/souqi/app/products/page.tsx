import { db } from "@/lib/db";
import { ProductCard } from "@/components/product-card";
export default async function ProductsPage() {
 const products = await db.product.findMany({ where: { isPublished: true }, include: { images: { orderBy: { sortOrder: "asc" }, take: 1 }, category: true }, orderBy: { createdAt: "desc" }});
 return <main className="container py-12"><h1 className="text-4xl font-bold">كل المنتجات</h1><p className="mt-2 text-[var(--muted)]">اكتشف أحدث المنتجات المختارة لك.</p><div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">{products.map(p=><ProductCard key={p.id} product={p}/>)}</div></main>
}
