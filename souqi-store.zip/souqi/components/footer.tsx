import Link from "next/link";
export function Footer() {
 return <footer className="mt-20 border-t border-[var(--border)] bg-white"><div className="container grid gap-10 py-12 md:grid-cols-4">
  <div><div className="text-xl font-bold">سوقي<span className="text-[var(--primary)]">.</span></div><p className="mt-3 text-sm text-[var(--muted)]">تجربة تسوق عربية بسيطة، موثوقة وسريعة.</p></div>
  <div><h3 className="font-semibold">خدمة العملاء</h3><div className="mt-3 grid gap-2 text-sm text-[var(--muted)]"><Link href="/contact">تواصل معنا</Link><Link href="/shipping">الشحن والتوصيل</Link><Link href="/returns">الاسترجاع</Link></div></div>
  <div><h3 className="font-semibold">سوقي</h3><div className="mt-3 grid gap-2 text-sm text-[var(--muted)]"><Link href="/about">عن سوقي</Link><Link href="/privacy">الخصوصية</Link><Link href="/terms">الشروط والأحكام</Link></div></div>
  <div><h3 className="font-semibold">تواصل معنا</h3><p className="mt-3 text-sm text-[var(--muted)]">المغرب · الدرهم المغربي (MAD)</p></div>
 </div><div className="border-t border-[var(--border)] py-5 text-center text-xs text-[var(--muted)]">© {new Date().getFullYear()} سوقي. جميع الحقوق محفوظة.</div></footer>
}
