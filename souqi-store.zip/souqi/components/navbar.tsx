import Link from "next/link";
import { Search, ShoppingBag, UserRound, Menu } from "lucide-react";

export function Navbar() {
  return <header className="sticky top-0 z-50 border-b border-[var(--border)] bg-white/90 backdrop-blur">
    <div className="container flex h-16 items-center gap-4">
      <Link href="/" className="text-2xl font-bold tracking-tight">سوقي<span className="text-[var(--primary)]">.</span></Link>
      <nav className="hidden items-center gap-6 md:flex">
        <Link href="/products" className="text-sm font-medium hover:text-[var(--primary)]">المنتجات</Link>
        <Link href="/categories" className="text-sm font-medium hover:text-[var(--primary)]">التصنيفات</Link>
      </nav>
      <form action="/search" className="mx-auto hidden w-full max-w-md md:block">
        <div className="flex items-center rounded-full border border-[var(--border)] bg-slate-50 px-4">
          <Search size={18} className="text-slate-400" />
          <input name="q" placeholder="ابحث عن منتج..." className="w-full bg-transparent px-3 py-2.5 outline-none" />
        </div>
      </form>
      <div className="mr-auto flex items-center gap-2">
        <Link href="/account" aria-label="الحساب" className="rounded-full p-2 hover:bg-slate-100"><UserRound size={20}/></Link>
        <Link href="/cart" aria-label="السلة" className="rounded-full p-2 hover:bg-slate-100"><ShoppingBag size={20}/></Link>
        <Link href="/products" className="rounded-full p-2 md:hidden" aria-label="القائمة"><Menu size={20}/></Link>
      </div>
    </div>
  </header>;
}
