import Link from "next/link";
import Image from "next/image";
import { Heart, ShoppingBag } from "lucide-react";
import { formatMAD } from "@/lib/utils";

type ProductCardProps = {
  product: { slug: string; name: string; basePrice: number; compareAtPrice: number | null; images: { url: string; alt: string }[]; category?: { name: string } | null };
};
export function ProductCard({ product }: ProductCardProps) {
 const discount = product.compareAtPrice ? Math.round((1 - product.basePrice / product.compareAtPrice) * 100) : 0;
 return <article className="group relative overflow-hidden rounded-2xl border border-[var(--border)] bg-white">
   <div className="absolute left-3 top-3 z-10 flex gap-2"><button className="rounded-full bg-white p-2 shadow-sm" aria-label="إضافة للمفضلة"><Heart size={17}/></button>{discount > 0 && <span className="rounded-full bg-[var(--primary)] px-2.5 py-1 text-xs font-semibold text-white">-{discount}%</span>}</div>
   <Link href={`/products/${product.slug}`}>
    <div className="relative aspect-square overflow-hidden bg-slate-100">{product.images[0] && <Image src={product.images[0].url} alt={product.images[0].alt} fill sizes="(max-width: 768px) 50vw, 25vw" className="object-cover transition duration-500 group-hover:scale-105"/>}</div>
    <div className="p-4"><p className="mb-1 text-xs text-[var(--muted)]">{product.category?.name}</p><h3 className="line-clamp-2 min-h-12 font-semibold">{product.name}</h3>
    <div className="mt-3 flex items-center gap-2"><strong className="text-lg">{formatMAD(product.basePrice)}</strong>{product.compareAtPrice && <del className="text-sm text-slate-400">{formatMAD(product.compareAtPrice)}</del>}</div></div>
   </Link>
   <button className="mx-4 mb-4 flex w-[calc(100%-2rem)] items-center justify-center gap-2 rounded-xl bg-[var(--foreground)] px-4 py-3 text-sm font-semibold text-white hover:bg-[var(--primary)]"><ShoppingBag size={17}/> أضف للسلة</button>
 </article>
}
