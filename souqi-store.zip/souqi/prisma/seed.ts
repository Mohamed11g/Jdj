import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
const db = new PrismaClient();
async function main() {
 const categories = await Promise.all(["الإلكترونيات","المنزل","الجمال والعناية","الأزياء","الرياضة","الإكسسوارات","الأطفال","العروض"].map((name,i)=>db.category.upsert({where:{slug:`cat-${i+1}`},update:{name},create:{name,slug:`cat-${i+1}`,sortOrder:i,isActive:true}})));
 const image = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1000&q=80";
 for (let i=1;i<=8;i++) {
   const category=categories[(i-1)%categories.length];
   await db.product.upsert({where:{slug:`souqi-product-${i}`},update:{},create:{name:["سماعات لاسلكية","حقيبة يومية أنيقة","ساعة رياضية ذكية","مصباح مكتبي عصري","حامل هاتف متعدد الاستخدام","زجاجة حرارية","منظم مكتب عملي","سماعة محمولة"][i-1],slug:`souqi-product-${i}`,description:"منتج عملي بتصميم عصري وجودة مناسبة للاستخدام اليومي.",basePrice:99+i*35,compareAtPrice:149+i*45,isPublished:true,categoryId:category.id,images:{create:{url:image,alt:"صورة المنتج",sortOrder:0}},inventory:{create:{stockQuantity:25,reservedQuantity:0,lowStockThreshold:5}}}});
 }
 const adminEmail=process.env.ADMIN_EMAIL;
 const adminPassword=process.env.ADMIN_PASSWORD;
 if(adminEmail && adminPassword) await db.user.upsert({where:{email:adminEmail},update:{role:"SUPER_ADMIN"},create:{name:"مدير سوقي",email:adminEmail,passwordHash:await hash(adminPassword,12),role:"SUPER_ADMIN"}});
}
main().finally(()=>db.$disconnect());
